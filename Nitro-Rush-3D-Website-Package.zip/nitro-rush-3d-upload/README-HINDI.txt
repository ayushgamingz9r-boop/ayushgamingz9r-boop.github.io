NITRO RUSH 3D - WEBSITE UPLOAD FILES

IS ZIP MEIN KYA HAI?
1. games/nitro-rush-3d/index.html = Browser mein chalne wala game.
2. downloads/Nitro-Rush-3D.apk = Android app download file.
3. nitro-rush-3d-card.html = AYUSH GAMING ke games page par lagane ke liye card ka code.

GITHUB PAR UPLOAD KARNE KE STEPS:
1. Apne AYUSH GAMING repository ko kholo.
2. ZIP ko phone mein extract karo.
3. Extracted folder ke andar games aur downloads folders ko repository ke ROOT mein upload karo. Existing files ko delete/replace mat karna.
4. nitro-rush-3d-card.html kholo, uska poora code copy karo aur apne games page (jaise index.html) mein jahan game card dikhana hai wahan paste karo.
5. Commit changes karo aur website deploy hone do.

IMPORTANT:
- Website ke root par /games/nitro-rush-3d/ aur /downloads/Nitro-Rush-3D.apk paths available hone chahiye.
- Browser game Three.js r128 ko cdnjs CDN se load karta hai, isliye online play ke liye internet connection chahiye.
- Agar tumhari website GitHub Pages ke project subpath par chalti hai (example: username.github.io/repository/), to card ke links mein starting slash hata kar relative paths use karo:
  games/nitro-rush-3d/
  downloads/Nitro-Rush-3D.apk
- APK install karte waqt Android security prompt aa sakta hai. Sirf apni banayi hui aur trusted APK hi install/share karo.
- APK ka browser game version APK ke andar se nikala gaya HTML build hai. Website par chalane se pehle mobile aur desktop browser mein test karna.
